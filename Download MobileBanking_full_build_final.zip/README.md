MobileBanking.legit - Full build

Quickstart:
1) npm install
2) npm run init-db
3) ADMIN_EMAIL=victorifeanyichukwu456@gmail.com ADMIN_PASSWORD=monica00@@ npm run seed-admin
4) npm start

Deploy notes: use Render Web Service (Node), Build: npm install, Start: npm start
